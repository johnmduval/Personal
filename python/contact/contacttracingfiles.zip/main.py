from contact_tracing import *

ct = ContactTracer("data/data3.csv")
print("Contact Records:")
print(ct)


bord = "-"*10+'\n'

print(bord,"Potential Zombies:\n")
zombies = ct.get_potential_zombies()
for zom in zombies:
  print(zom.label)
  

print(bord,"Patient Zeros:\n")
p_zeros = ct.get_patient_zeros()
for patient in p_zeros:
  print(patient.label)




print(bord,"Closest Patient-Zero - Zombie Connections:\n")


# Vertex Objects: Sarai, Philip 
for zom in zombies:
  closest_patient = None 
  closest_dist = float('inf')
  # Vertex Objects: Bob, Farley, Larry
  for patient in p_zeros:
    ct.dijkstra_shortest_path(patient)
    if zom.distance < closest_dist:
      closest_dist = zom.distance
      closest_patient = patient
      # print(f"distance: {closest_dist}\n closest zero: {closest_patient}")
    # print(f"zom: {zom} patient: {patient}\nPath: {ct.print_shortest_path(patient,zom)}")

  if closest_patient != None:
    ct.print_shortest_path(closest_patient,zom)

